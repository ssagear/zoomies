"""
This is the __init__.py file for zoomies
"""

__version__ = "0.0.1"

from .quick_jz import *
from .kinematic_relation import *
