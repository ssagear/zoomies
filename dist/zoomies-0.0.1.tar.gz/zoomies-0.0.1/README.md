# zoomies

Stars get the zoomies too. This is a kinematic age prediction package that uses only Gaia parallax, proper motion, and radial velocity to produce a stellar age prediction based on its galactic orbit.

To install: 

```
git clone https://github.com/ssagear/zoomies

cd zoomies

pip install .
```
Under active development proceed with caution 